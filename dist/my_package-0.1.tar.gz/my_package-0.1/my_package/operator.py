def operator():
    return "operator"